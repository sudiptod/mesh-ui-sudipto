import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { FormsModule } from '@angular/forms';
import { Routes, RouterModule } from '@angular/router';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CdsModule } from '@cds/angular';
import { ClarityModule } from '@clr/angular';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DashboardComponent } from './dashboard/dashboard.component';
import { ServicecomparisonComponent } from './servicecomparison/servicecomparison.component';
import { SlowqueryanalysisComponent } from './slowqueryanalysis/slowqueryanalysis.component';
import { TracingComponent } from './tracing/tracing.component';
import { Route } from '@angular/compiler/src/core';


const appRoutes: Routes=[
  { path: '', component: DashboardComponent},
  { path: 'servicemesh', component: DashboardComponent},
  { path: 'slowqueryanalysis', component: SlowqueryanalysisComponent},
  { path: 'servicecomparison', component: ServicecomparisonComponent},
  { path: 'tracing', component: TracingComponent},

];


@NgModule({
  declarations: [
    AppComponent,
    DashboardComponent,
    ServicecomparisonComponent,
    SlowqueryanalysisComponent,
    TracingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    CdsModule,
    ClarityModule,
    BrowserAnimationsModule,
    FormsModule,
    RouterModule.forRoot(appRoutes)

  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
