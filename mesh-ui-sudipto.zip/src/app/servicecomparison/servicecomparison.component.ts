import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-servicecomparison',
  templateUrl: './servicecomparison.component.html',
  styleUrls: ['./servicecomparison.component.css']
})
export class ServicecomparisonComponent implements OnInit {
  fromDate = '';
  toDate = '';
  timerange = '';
  services = '';
  gbtnclassname = 'btn-primary';
  tbtnclassname = '';
  tabular = 'display:none;';
  graphical = 'display:block;';
  constructor() { }

  ngOnInit(): void {
  }
  onGraph(){
    this.gbtnclassname = 'btn-primary';
    this.tbtnclassname = '';
    this.tabular = 'display:none;';
    this.graphical = 'display:block;';
  }

  onTable(){
    this.tbtnclassname = 'btn-primary';
    this.gbtnclassname = '';
    this.tabular = 'display:block;';
    this.graphical = 'display:none;';
  }
}
