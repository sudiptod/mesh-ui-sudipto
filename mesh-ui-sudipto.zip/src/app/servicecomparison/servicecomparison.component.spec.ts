import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ServicecomparisonComponent } from './servicecomparison.component';

describe('ServicecomparisonComponent', () => {
  let component: ServicecomparisonComponent;
  let fixture: ComponentFixture<ServicecomparisonComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ServicecomparisonComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ServicecomparisonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
