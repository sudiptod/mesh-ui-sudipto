import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tracing',
  templateUrl: './tracing.component.html',
  styleUrls: ['./tracing.component.css']
})
export class TracingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
