import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-slowqueryanalysis',
  templateUrl: './slowqueryanalysis.component.html',
  styleUrls: ['./slowqueryanalysis.component.css']
})
export class SlowqueryanalysisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
