import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SlowqueryanalysisComponent } from './slowqueryanalysis.component';

describe('SlowqueryanalysisComponent', () => {
  let component: SlowqueryanalysisComponent;
  let fixture: ComponentFixture<SlowqueryanalysisComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SlowqueryanalysisComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SlowqueryanalysisComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
